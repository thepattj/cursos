<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">     

	<link href="<?php echo base_url().'assets/css/bootstrap.css'; ?>" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

    <!-- custom CSS -->
    <link href="<?php echo base_url().'assets/css/modern-business.css'; ?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/font-awesome/css/font-awesome.min.css'; ?>" type="text/css" rel="stylesheet">

	<title>SIN ACCESO</title>
</head>


<body>
	<div class="body">
		<BR><BR><BR><BR><BR><BR>
		<section class="container">
			<div class="row">
				<div class="col-lg-3 col-md-2 col-sm-2 col-xs-1 text-center"></div>
				<div class="col-lg-6 col-md-8 col-sm-8 col-xs-10 text-center  well panel-azul-claro">	
					<div class="sinAcceso">NO TIENES ACCESO</div>
					<BR><BR>
					<center>
						<img src="<?php echo base_url().'assets/imagenes/sad.png'; ?>" style="width: 50%">						
					</center>
					<BR>
				</div>
				<div class="col-lg-3 col-md-2 col-sm-2 text-center"></div>
			</div>

		</section>
 	</div>

</body>

</html>
