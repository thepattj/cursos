          
          </section>
      </section>


  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url()."assets/admin/"; ?>/js/jquery.js"></script>
    <script src="<?php echo base_url()."assets/admin/"; ?>/js/jquery-1.8.3.min.js"></script>
    <script src="<?php echo base_url()."assets/admin/"; ?>/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo base_url()."assets/admin/"; ?>/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo base_url()."assets/admin/"; ?>/js/jquery.scrollTo.min.js"></script>
    <script src="<?php echo base_url()."assets/admin/"; ?>/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="<?php echo base_url()."assets/admin/"; ?>/js/jquery.sparkline.js"></script>


    <!--common script for all pages-->
    <script src="<?php echo base_url()."assets/admin/"; ?>/js/common-scripts.js"></script>
    
    <script type="text/javascript" src="<?php echo base_url()."assets/admin/"; ?>/js/gritter/js/jquery.gritter.js"></script>
    <script type="text/javascript" src="<?php echo base_url()."assets/admin/"; ?>/js/gritter-conf.js"></script>

    <!--script for this page-->
    <script src="<?php echo base_url()."assets/admin/"; ?>/js/sparkline-chart.js"></script>    
  	<script src="<?php echo base_url()."assets/admin/"; ?>/js/zabuto_calendar.js"></script>	
	


  <!--script for this page-->
  <script src="<?php echo base_url()."assets/admin/"; ?>/js/jquery-ui-1.9.2.custom.min.js"></script>
  <!--custom switch-->
  <script src="<?php echo base_url()."assets/admin/"; ?>/js/bootstrap-switch.js"></script>
  <!--custom tagsinput-->
  <script src="<?php echo base_url()."assets/admin/"; ?>/js/jquery.tagsinput.js"></script>
  
  <!--custom checkbox & radio-->
  <script type="text/javascript" src="<?php echo base_url()."assets/admin/"; ?>/js/bootstrap-inputmask/bootstrap-inputmask.min.js"></script>
  <script src="<?php echo base_url()."assets/admin/"; ?>/js/form-component.js"></script> 



  </body>
</html>
