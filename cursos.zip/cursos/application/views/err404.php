
<BR>
<BR>
<BR>


<!-- H1><CENTER><?php echo $subtitulo; ?></CENTER></H1 -->

<div class="row">
	
	<div class="col-lg-3 col-md-2 col-sm-1 col-xs-1 text-center">
    </div>

	<div class="col-lg-6 col-md-8 col-sm-10 col-xs-10 text-center">
    <!-- INI Contenido -->   
        <BR>
        <BR>

        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 text-center"> 
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-center">
                <CENTER><img src="<?php echo base_url().'/assets/imagenes/error_404.jpg'; ?>" style="width: 100%"></CENTER>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 text-center"> 
            </div>
        </div>

        <BR>
        <BR>

    <!-- FIN Contenido -->   

	</div>

	<div class="col-lg-3 col-md-2 col-sm-1 col-xs-1 text-center">
    </div>

</div>


<BR>
<BR>
<BR>